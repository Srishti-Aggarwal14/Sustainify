from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
from flask_session import Session

app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Required for session management

# MongoDB Configuration (Local)
client = MongoClient("mongodb://localhost:27017/")  # Local MongoDB connection string
db = client["sustainify"]  # Database name
users_collection = db["users"]  # Collection for user data

# Flask-Session Configuration
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Routes
@app.route("/")
def home():
    if "email" in session:
        return render_template("home.html", user=session["email"])
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        # Check if the user exists in the database
        user = users_collection.find_one({"email": email})

        if user and user["password"] == password:
            session["email"] = email  # Store user email in session
            return redirect(url_for("home"))  # Redirect to home page after successful login
        else:
            return "Invalid credentials, try again!"

    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        fullname = request.form.get("fullname")
        email = request.form.get("email")
        password = request.form.get("password")

        # Check if the email already exists
        if users_collection.find_one({"email": email}):
            return "Email already exists!"
        else:
            # Insert new user into the database
            users_collection.insert_one({
                "fullname": fullname,
                "email": email,
                "password": password
            })
            session["email"] = email  # Store user email in session
            return redirect(url_for("home"))  # Redirect to home page after successful signup

    return render_template("signup.html")

@app.route("/logout")
def logout():
    session.pop("email", None)  # Remove user email from session
    return redirect(url_for("home"))  # Redirect to home page after logout

@app.route("/calculator")
def calculator():
    return render_template("calculator.html")

# Add routes for all sidebar options
@app.route("/leaderboard")
def leaderboard():
    return render_template("leaderboard.html")

@app.route("/events")
def events():
    return render_template("events.html")

@app.route("/progress")
def progress():
    return render_template("progress.html")

@app.route("/community")
def community():
    return render_template("community.html")

@app.route("/blog")
def blog():
    return render_template("blog.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/challenges")
def challenges():
    return render_template("challenges.html")

@app.route("/shop")
def shop():
    return render_template("shop.html")

@app.route("/changes")
def changes():
    return render_template("changes.html")

if __name__ == "__main__":
    app.run(debug=True)